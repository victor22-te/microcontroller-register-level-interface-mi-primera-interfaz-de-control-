#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <util/delay.h>
#include <string.h>
#include <stdlib.h>
char str[80];
#include "serial.h"
#include "hcsr04.h"
#define BAUD 9600
#define MYUBRR F_CPU/16/BAUD-1

void USART_Init(unsigned int ubrr) {
	UBRR0H = (unsigned char)(ubrr >> 8);
	UBRR0L = (unsigned char)ubrr;
	UCSR0B = (1 << RXEN0) | (1 << TXEN0);
	UCSR0C = (3 << UCSZ00);
}

void USART_Transmit(char data) {
	while (!(UCSR0A & (1 << UDRE0)));
	UDR0 = data;
}

int main(void) {
	USART_Init(MYUBRR);
	HCSR04_init();

	while (1) {
		float HCSR04_data;

		// HCSR04
		HCSR04_data = medir_distancia_cm();

		// 60 ms de espera
		_delay_ms(6000);

		sprintf(str, "D%.3f\r\n", HCSR04_data);
		usart0_puts(str);

		// Other tasks after the inner loop
	}

	return 0;
}
